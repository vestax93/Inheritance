package exerecise1;

public class Dog extends Animal{
    //String name = "dog";
    public void bark(){
        //super.eat();
        System.out.println("barking..."); //super.name + "barking"
    }
}
