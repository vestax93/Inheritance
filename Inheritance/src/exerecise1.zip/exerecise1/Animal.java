package exerecise1;

public class Animal {
    //String name = "animal";
    public void eat(){
        System.out.println("eating...");
    }
}
